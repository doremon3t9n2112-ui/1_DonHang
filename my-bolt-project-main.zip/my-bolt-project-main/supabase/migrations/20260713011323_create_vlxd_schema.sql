/*
# Vật Liệu Xây Dựng Song Thịnh - Database Schema

## Overview
Creates the full schema for a construction-materials ordering system:
customers browse products, place orders with delivery details, and the
shop admin (Song Thịnh) manages orders and inventory.

## New Tables

### categories
- `id` (uuid, PK)
- `name` (text) - e.g. "Cát", "Đá", "Xi măng", "Gạch", "Sắt thép"
- `slug` (text, unique) - URL-friendly identifier
- `icon` (text) - lucide icon name for display
- `sort_order` (int) - display ordering

### products
- `id` (uuid, PK)
- `category_id` (uuid, FK -> categories)
- `name` (text)
- `description` (text)
- `price` (numeric) - price per unit
- `unit` (text) - "bao", "khối", "tấn", "thiên", "viên"
- `stock` (numeric) - current inventory quantity
- `image_url` (text) - product photo
- `is_active` (boolean) - soft toggle to hide products
- `created_at` (timestamptz)

### orders
- `id` (uuid, PK)
- `order_code` (text, unique) - human-readable order number (ST-XXXX)
- `customer_name` (text)
- `customer_phone` (text)
- `address` (text) - delivery address
- `lat` (numeric, nullable) - map pin latitude
- `lng` (numeric, nullable) - map pin longitude
- `notes` (text, nullable) - delivery notes
- `status` (text) - pending | confirmed | delivering | delivered | cancelled
- `payment_method` (text) - cod | deposit | bank_transfer
- `subtotal` (numeric) - sum of item prices
- `shipping_fee` (numeric) - calculated shipping cost
- `total` (numeric) - subtotal + shipping_fee
- `distance_km` (numeric, nullable) - calculated distance for shipping
- `created_at` (timestamptz)
- `updated_at` (timestamptz)

### order_items
- `id` (uuid, PK)
- `order_id` (uuid, FK -> orders, cascade delete)
- `product_id` (uuid, FK -> products, nullable - nullable in case product is later removed)
- `product_name` (text) - snapshot of name at order time
- `quantity` (numeric)
- `unit` (text)
- `price` (numeric) - snapshot of price at order time

## Security
- RLS enabled on all tables.
- All tables use `TO anon, authenticated` because this is a no-sign-in app:
  customers place orders anonymously and the admin panel is a simple route.
- Full CRUD allowed for anon+authenticated on all tables (shared/public data model).
*/

-- Categories
CREATE TABLE IF NOT EXISTS categories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  slug text UNIQUE NOT NULL,
  icon text NOT NULL DEFAULT 'Package',
  sort_order int NOT NULL DEFAULT 0
);

ALTER TABLE categories ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "anon_select_categories" ON categories;
CREATE POLICY "anon_select_categories" ON categories FOR SELECT
  TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_categories" ON categories;
CREATE POLICY "anon_insert_categories" ON categories FOR INSERT
  TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_update_categories" ON categories;
CREATE POLICY "anon_update_categories" ON categories FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_categories" ON categories;
CREATE POLICY "anon_delete_categories" ON categories FOR DELETE
  TO anon, authenticated USING (true);

-- Products
CREATE TABLE IF NOT EXISTS products (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  category_id uuid REFERENCES categories(id) ON DELETE SET NULL,
  name text NOT NULL,
  description text DEFAULT '',
  price numeric NOT NULL DEFAULT 0,
  unit text NOT NULL DEFAULT 'khối',
  stock numeric NOT NULL DEFAULT 0,
  image_url text DEFAULT '',
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE products ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "anon_select_products" ON products;
CREATE POLICY "anon_select_products" ON products FOR SELECT
  TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_products" ON products;
CREATE POLICY "anon_insert_products" ON products FOR INSERT
  TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_update_products" ON products;
CREATE POLICY "anon_update_products" ON products FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_products" ON products;
CREATE POLICY "anon_delete_products" ON products FOR DELETE
  TO anon, authenticated USING (true);

-- Orders
CREATE TABLE IF NOT EXISTS orders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_code text UNIQUE NOT NULL,
  customer_name text NOT NULL,
  customer_phone text NOT NULL,
  address text NOT NULL,
  lat numeric,
  lng numeric,
  notes text DEFAULT '',
  status text NOT NULL DEFAULT 'pending',
  payment_method text NOT NULL DEFAULT 'cod',
  subtotal numeric NOT NULL DEFAULT 0,
  shipping_fee numeric NOT NULL DEFAULT 0,
  total numeric NOT NULL DEFAULT 0,
  distance_km numeric,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE orders ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "anon_select_orders" ON orders;
CREATE POLICY "anon_select_orders" ON orders FOR SELECT
  TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_orders" ON orders;
CREATE POLICY "anon_insert_orders" ON orders FOR INSERT
  TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_update_orders" ON orders;
CREATE POLICY "anon_update_orders" ON orders FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_orders" ON orders;
CREATE POLICY "anon_delete_orders" ON orders FOR DELETE
  TO anon, authenticated USING (true);

-- Order items
CREATE TABLE IF NOT EXISTS order_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id uuid REFERENCES orders(id) ON DELETE CASCADE,
  product_id uuid REFERENCES products(id) ON DELETE SET NULL,
  product_name text NOT NULL,
  quantity numeric NOT NULL DEFAULT 1,
  unit text NOT NULL,
  price numeric NOT NULL DEFAULT 0
);

ALTER TABLE order_items ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "anon_select_order_items" ON order_items;
CREATE POLICY "anon_select_order_items" ON order_items FOR SELECT
  TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_order_items" ON order_items;
CREATE POLICY "anon_insert_order_items" ON order_items FOR INSERT
  TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_update_order_items" ON order_items;
CREATE POLICY "anon_update_order_items" ON order_items FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_order_items" ON order_items;
CREATE POLICY "anon_delete_order_items" ON order_items FOR DELETE
  TO anon, authenticated USING (true);

-- Indexes
CREATE INDEX IF NOT EXISTS idx_products_category ON products(category_id);
CREATE INDEX IF NOT EXISTS idx_orders_status ON orders(status);
CREATE INDEX IF NOT EXISTS idx_orders_created ON orders(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_order_items_order ON order_items(order_id);
