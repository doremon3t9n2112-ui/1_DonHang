/*
# Admin Authentication & Owner Approval System

## Overview
Adds email/password authentication for the admin panel. New users sign up
but must be approved by the owner (chủ quản) before they can access admin
features. The first registered user automatically becomes the owner with
approved status.

## New Tables

### profiles
- `id` (uuid, PK, FK -> auth.users) — matches the auth user's id
- `email` (text) — snapshot of the auth email
- `full_name` (text) — display name
- `role` (text) — 'owner' | 'admin' (owner = chủ quản, admin = nhân viên)
- `status` (text) — 'pending' | 'approved' | 'rejected'
- `created_at` (timestamptz)

## New Functions

### handle_new_user()
Trigger function that fires on INSERT into auth.users. Auto-creates a
profile row. The first user to register gets role='owner' and status='approved'.
All subsequent users get role='admin' and status='pending' (require owner approval).

## Security Changes (RLS)

### profiles
- SELECT: users can read their own profile; approved users can read all profiles
- UPDATE: only the owner can update profiles (approve/reject users)

### categories, products
- SELECT: anon + authenticated (public catalog)
- INSERT/UPDATE/DELETE: only approved authenticated users

### orders
- SELECT: anon + authenticated (customers track orders by phone)
- INSERT: anon + authenticated (customers place orders)
- UPDATE/DELETE: only approved authenticated users

### order_items
- SELECT: anon + authenticated
- INSERT: anon + authenticated (created with order)
- UPDATE/DELETE: only approved authenticated users

## Important Notes
1. The first user to sign up is auto-approved as owner.
2. Subsequent users see a "pending approval" screen until the owner approves them.
3. Email confirmation is OFF (per Supabase default for this project).
*/

-- Profiles table
CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email text NOT NULL,
  full_name text DEFAULT '',
  role text NOT NULL DEFAULT 'admin',
  status text NOT NULL DEFAULT 'pending',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

-- Profiles: users can read their own profile; approved users can read all
DROP POLICY IF EXISTS "select_own_profile" ON profiles;
CREATE POLICY "select_own_profile" ON profiles FOR SELECT
  TO authenticated USING (
    auth.uid() = id
    OR EXISTS (
      SELECT 1 FROM profiles p
      WHERE p.id = auth.uid() AND p.status = 'approved'
    )
  );

-- Profiles: only owner can update (approve/reject users)
DROP POLICY IF EXISTS "update_profiles_owner" ON profiles;
CREATE POLICY "update_profiles_owner" ON profiles FOR UPDATE
  TO authenticated USING (
    EXISTS (
      SELECT 1 FROM profiles p
      WHERE p.id = auth.uid() AND p.role = 'owner'
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM profiles p
      WHERE p.id = auth.uid() AND p.role = 'owner'
    )
  );

-- Function to auto-create profile on signup
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  user_count int;
BEGIN
  SELECT count(*) INTO user_count FROM profiles;
  IF user_count = 0 THEN
    INSERT INTO profiles (id, email, full_name, role, status)
    VALUES (NEW.id, NEW.email, COALESCE(NEW.raw_user_meta_data->>'full_name', ''), 'owner', 'approved');
  ELSE
    INSERT INTO profiles (id, email, full_name, role, status)
    VALUES (NEW.id, NEW.email, COALESCE(NEW.raw_user_meta_data->>'full_name', ''), 'admin', 'pending');
  END IF;
  RETURN NEW;
END;
$$;

-- Trigger on auth.users
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- ============================================================
-- Tighten RLS on existing tables
-- ============================================================

-- Categories: public read, approved-user write
DROP POLICY IF EXISTS "anon_insert_categories" ON categories;
DROP POLICY IF EXISTS "anon_update_categories" ON categories;
DROP POLICY IF EXISTS "anon_delete_categories" ON categories;

DROP POLICY IF EXISTS "approved_write_categories" ON categories;
CREATE POLICY "approved_write_categories" ON categories FOR INSERT
  TO authenticated WITH CHECK (
    EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.status = 'approved')
  );
DROP POLICY IF EXISTS "approved_update_categories" ON categories;
CREATE POLICY "approved_update_categories" ON categories FOR UPDATE
  TO authenticated USING (
    EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.status = 'approved')
  ) WITH CHECK (
    EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.status = 'approved')
  );
DROP POLICY IF EXISTS "approved_delete_categories" ON categories;
CREATE POLICY "approved_delete_categories" ON categories FOR DELETE
  TO authenticated USING (
    EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.status = 'approved')
  );

-- Products: public read, approved-user write
DROP POLICY IF EXISTS "anon_insert_products" ON products;
DROP POLICY IF EXISTS "anon_update_products" ON products;
DROP POLICY IF EXISTS "anon_delete_products" ON products;

DROP POLICY IF EXISTS "approved_write_products" ON products;
CREATE POLICY "approved_write_products" ON products FOR INSERT
  TO authenticated WITH CHECK (
    EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.status = 'approved')
  );
DROP POLICY IF EXISTS "approved_update_products" ON products;
CREATE POLICY "approved_update_products" ON products FOR UPDATE
  TO authenticated USING (
    EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.status = 'approved')
  ) WITH CHECK (
    EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.status = 'approved')
  );
DROP POLICY IF EXISTS "approved_delete_products" ON products;
CREATE POLICY "approved_delete_products" ON products FOR DELETE
  TO authenticated USING (
    EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.status = 'approved')
  );

-- Orders: public read+insert, approved-user update+delete
DROP POLICY IF EXISTS "anon_update_orders" ON orders;
DROP POLICY IF EXISTS "anon_delete_orders" ON orders;

DROP POLICY IF EXISTS "approved_update_orders" ON orders;
CREATE POLICY "approved_update_orders" ON orders FOR UPDATE
  TO authenticated USING (
    EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.status = 'approved')
  ) WITH CHECK (
    EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.status = 'approved')
  );
DROP POLICY IF EXISTS "approved_delete_orders" ON orders;
CREATE POLICY "approved_delete_orders" ON orders FOR DELETE
  TO authenticated USING (
    EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.status = 'approved')
  );

-- Order items: public read+insert, approved-user update+delete
DROP POLICY IF EXISTS "anon_update_order_items" ON order_items;
DROP POLICY IF EXISTS "anon_delete_order_items" ON order_items;

DROP POLICY IF EXISTS "approved_update_order_items" ON order_items;
CREATE POLICY "approved_update_order_items" ON order_items FOR UPDATE
  TO authenticated USING (
    EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.status = 'approved')
  ) WITH CHECK (
    EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.status = 'approved')
  );
DROP POLICY IF EXISTS "approved_delete_order_items" ON order_items;
CREATE POLICY "approved_delete_order_items" ON order_items FOR DELETE
  TO authenticated USING (
    EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.status = 'approved')
  );
