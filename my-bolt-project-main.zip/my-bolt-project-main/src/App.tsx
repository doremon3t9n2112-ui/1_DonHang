import { CartProvider } from './lib/cart';
import { RouterProvider, useRouter } from './lib/router';
import { AuthProvider, useAuth } from './lib/auth';
import { Header, FloatingButtons } from './components/Header';
import { Footer } from './components/Footer';
import { Home } from './pages/Home';
import { Products } from './pages/Products';
import { Cart } from './pages/Cart';
import { Checkout } from './pages/Checkout';
import { OrderSuccess } from './pages/OrderSuccess';
import { Track } from './pages/Track';
import { Admin } from './pages/Admin';
import { Login } from './pages/Login';
import { PendingApproval } from './pages/PendingApproval';
import { Loader2 } from 'lucide-react';

function AdminRoute() {
  const { session, profile, loading } = useAuth();

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <Loader2 className="w-8 h-8 animate-spin text-stone-400" />
      </div>
    );
  }

  if (!session) {
    return <Login />;
  }

  if (profile?.status === 'pending') {
    return <PendingApproval />;
  }

  if (profile?.status === 'rejected') {
    return <PendingApproval />;
  }

  if (profile?.status === 'approved') {
    return <Admin />;
  }

  // Profile not yet loaded — show loading
  return (
    <div className="flex items-center justify-center py-20">
      <Loader2 className="w-8 h-8 animate-spin text-stone-400" />
    </div>
  );
}

function Routes() {
  const { path } = useRouter();
  const route = path.split('?')[0];

  return (
    <div className="min-h-screen flex flex-col bg-stone-50">
      <Header />
      <main className="flex-1">
        {route === '/' && <Home />}
        {route === '/products' && <Products />}
        {route === '/cart' && <Cart />}
        {route === '/checkout' && <Checkout />}
        {route === '/order-success' && <OrderSuccess />}
        {route === '/track' && <Track />}
        {route === '/admin' && <AdminRoute />}
        {route === '/login' && <Login />}
      </main>
      <Footer />
      <FloatingButtons />
    </div>
  );
}

function App() {
  return (
    <RouterProvider>
      <AuthProvider>
        <CartProvider>
          <Routes />
        </CartProvider>
      </AuthProvider>
    </RouterProvider>
  );
}

export default App;
