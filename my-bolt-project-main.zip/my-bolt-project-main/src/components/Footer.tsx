import { Phone, MessageCircle, MapPin, ShieldCheck } from 'lucide-react';
import { useRouter } from '../lib/router';

export function Footer() {
  const { navigate } = useRouter();
  return (
    <footer className="bg-stone-900 text-stone-300 mt-12">
      <div className="max-w-7xl mx-auto px-4 py-10">
        <div className="grid md:grid-cols-3 gap-8">
          <div>
            <div className="flex items-center gap-2 mb-3">
              <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-amber-600 to-orange-700 flex items-center justify-center">
                <span className="text-white font-bold">ST</span>
              </div>
              <div>
                <div className="font-bold text-white">Song Thịnh</div>
                <div className="text-xs text-stone-400">Vật Liệu Xây Dựng</div>
              </div>
            </div>
            <p className="text-sm text-stone-400">
              Cung cấp cát, đá, xi măng, gạch, sắt thép — giao tận công trình. Giá cả cạnh tranh, chất lượng đảm bảo.
            </p>
          </div>

          <div>
            <h3 className="font-semibold text-white mb-3">Liên hệ</h3>
            <div className="space-y-2 text-sm">
              <a href="tel:0901234567" className="flex items-center gap-2 hover:text-white transition-colors">
                <Phone className="w-4 h-4" /> 0901 234 567
              </a>
              <a href="https://zalo.me/0901234567" target="_blank" rel="noopener noreferrer" className="flex items-center gap-2 hover:text-white transition-colors">
                <MessageCircle className="w-4 h-4" /> Chat Zalo
              </a>
              <p className="flex items-start gap-2">
                <MapPin className="w-4 h-4 mt-0.5" /> Kho vật liệu Song Thịnh, Q. Bình Tân, TP. HCM
              </p>
            </div>
          </div>

          <div>
            <h3 className="font-semibold text-white mb-3">Liên kết</h3>
            <div className="space-y-2 text-sm">
              <button onClick={() => navigate('/')} className="block hover:text-white transition-colors">Trang chủ</button>
              <button onClick={() => navigate('/products')} className="block hover:text-white transition-colors">Sản phẩm</button>
              <button onClick={() => navigate('/track')} className="block hover:text-white transition-colors">Theo dõi đơn hàng</button>
              <button onClick={() => navigate('/admin')} className="block hover:text-white transition-colors">Quản lý</button>
            </div>
          </div>
        </div>
        <div className="border-t border-stone-700 mt-8 pt-6 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-sm text-stone-500 text-center sm:text-left">
            © 2026 Vật Liệu Xây Dựng Song Thịnh. All rights reserved.
          </p>
          <button
            onClick={() => navigate('/login')}
            className="flex items-center gap-2 px-4 py-2 rounded-lg bg-stone-800 hover:bg-stone-700 text-stone-300 hover:text-white text-sm font-medium transition-colors border border-stone-700"
          >
            <ShieldCheck className="w-4 h-4" />
            Đăng Nhập Admin
          </button>
        </div>
      </div>
    </footer>
  );
}
