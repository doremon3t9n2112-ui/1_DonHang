import { ShoppingBag, Phone, MessageCircle, Menu, X } from 'lucide-react';
import { useState } from 'react';
import { useCart } from '../lib/cart';
import { useRouter } from '../lib/router';
import { useAuth } from '../lib/auth';

export function Header() {
  const { count } = useCart();
  const { navigate, path } = useRouter();
  const { profile } = useAuth();
  const [menuOpen, setMenuOpen] = useState(false);

  const navItems = [
    { label: 'Trang chủ', path: '/' },
    { label: 'Sản phẩm', path: '/products' },
    { label: 'Theo dõi đơn', path: '/track' },
    ...(profile?.status === 'approved' ? [{ label: 'Quản lý', path: '/admin' }] : []),
  ];

  return (
    <header className="sticky top-0 z-40 bg-white shadow-md border-b border-stone-200">
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          <button onClick={() => navigate('/')} className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-amber-600 to-orange-700 flex items-center justify-center shadow-sm">
              <span className="text-white font-bold text-lg">ST</span>
            </div>
            <div className="text-left">
              <div className="font-bold text-stone-800 leading-tight">Song Thịnh</div>
              <div className="text-xs text-stone-500 leading-tight">Vật Liệu Xây Dựng</div>
            </div>
          </button>

          <nav className="hidden md:flex items-center gap-1">
            {navItems.map((item) => (
              <button
                key={item.path}
                onClick={() => navigate(item.path)}
                className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                  path === item.path
                    ? 'bg-amber-50 text-amber-700'
                    : 'text-stone-600 hover:text-amber-700 hover:bg-stone-50'
                }`}
              >
                {item.label}
              </button>
            ))}
          </nav>

          <div className="flex items-center gap-2">
            <button
              onClick={() => navigate('/cart')}
              className="relative p-2 rounded-lg hover:bg-stone-100 transition-colors"
            >
              <ShoppingBag className="w-6 h-6 text-stone-700" />
              {count > 0 && (
                <span className="absolute -top-1 -right-1 bg-amber-600 text-white text-xs font-bold rounded-full w-5 h-5 flex items-center justify-center">
                  {count}
                </span>
              )}
            </button>
            <button
              onClick={() => setMenuOpen(!menuOpen)}
              className="md:hidden p-2 rounded-lg hover:bg-stone-100"
            >
              {menuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>

        {menuOpen && (
          <nav className="md:hidden pb-3 flex flex-col gap-1">
            {navItems.map((item) => (
              <button
                key={item.path}
                onClick={() => {
                  navigate(item.path);
                  setMenuOpen(false);
                }}
                className={`px-4 py-2.5 rounded-lg text-sm font-medium text-left transition-colors ${
                  path === item.path
                    ? 'bg-amber-50 text-amber-700'
                    : 'text-stone-600 hover:bg-stone-50'
                }`}
              >
                {item.label}
              </button>
            ))}
          </nav>
        )}
      </div>
    </header>
  );
}

export function FloatingButtons() {
  return (
    <div className="fixed bottom-4 right-4 z-40 flex flex-col gap-3">
      <a
        href="https://zalo.me/0901234567"
        target="_blank"
        rel="noopener noreferrer"
        className="w-14 h-14 rounded-full bg-blue-500 shadow-lg flex items-center justify-center hover:scale-110 transition-transform"
        title="Chat Zalo"
      >
        <MessageCircle className="w-7 h-7 text-white" />
      </a>
      <a
        href="tel:0901234567"
        className="w-14 h-14 rounded-full bg-emerald-600 shadow-lg flex items-center justify-center hover:scale-110 transition-transform"
        title="Gọi điện"
      >
        <Phone className="w-7 h-7 text-white" />
      </a>
    </div>
  );
}
