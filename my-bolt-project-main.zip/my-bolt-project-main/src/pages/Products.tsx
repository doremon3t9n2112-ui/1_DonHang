import { useEffect, useState } from 'react';
import { Plus, Minus, ShoppingCart, Search, Package } from 'lucide-react';
import { supabase, type Category, type Product, formatPrice, formatNumber } from '../lib/supabase';
import { useCart } from '../lib/cart';
import { useRouter } from '../lib/router';

export function Products() {
  const [categories, setCategories] = useState<Category[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [activeCat, setActiveCat] = useState<string>('all');
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(true);
  const [quantities, setQuantities] = useState<Record<string, number>>({});
  const { addItem } = useCart();
  const { navigate } = useRouter();

  useEffect(() => {
    const params = new URLSearchParams(window.location.hash.split('?')[1] || '');
    const cat = params.get('cat');
    if (cat) setActiveCat(cat);
  }, []);

  useEffect(() => {
    (async () => {
      setLoading(true);
      const [{ data: cats }, { data: prods }] = await Promise.all([
        supabase.from('categories').select('*').order('sort_order'),
        supabase.from('products').select('*').eq('is_active', true).order('name'),
      ]);
      setCategories(cats || []);
      setProducts(prods || []);
      setLoading(false);
    })();
  }, []);

  const filtered = products.filter((p) => {
    const matchCat = activeCat === 'all' || p.category_id === categories.find((c) => c.slug === activeCat)?.id;
    const matchSearch = !search || p.name.toLowerCase().includes(search.toLowerCase());
    return matchCat && matchSearch;
  });

  const getQty = (id: string) => quantities[id] ?? 1;
  const setQty = (id: string, qty: number) => setQuantities((prev) => ({ ...prev, [id]: Math.max(1, qty) }));

  const handleAdd = (p: Product) => {
    addItem(p, getQty(p.id));
    navigate('/cart');
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-6">
      <h1 className="text-2xl font-bold text-stone-800 mb-4">Sản phẩm</h1>

      {/* Search */}
      <div className="relative mb-4">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-stone-400" />
        <input
          type="text"
          placeholder="Tìm kiếm vật liệu..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-stone-200 focus:border-amber-400 focus:ring-2 focus:ring-amber-100 outline-none"
        />
      </div>

      {/* Category tabs */}
      <div className="flex gap-2 overflow-x-auto pb-3 mb-4 -mx-4 px-4">
        <button
          onClick={() => setActiveCat('all')}
          className={`px-4 py-2 rounded-lg whitespace-nowrap text-sm font-medium transition-colors ${
            activeCat === 'all' ? 'bg-amber-600 text-white' : 'bg-white text-stone-600 border border-stone-200 hover:border-amber-300'
          }`}
        >
          Tất cả
        </button>
        {categories.map((c) => (
          <button
            key={c.id}
            onClick={() => setActiveCat(c.slug)}
            className={`px-4 py-2 rounded-lg whitespace-nowrap text-sm font-medium transition-colors ${
              activeCat === c.slug ? 'bg-amber-600 text-white' : 'bg-white text-stone-600 border border-stone-200 hover:border-amber-300'
            }`}
          >
            {c.name}
          </button>
        ))}
      </div>

      {/* Products grid */}
      {loading ? (
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {Array.from({ length: 8 }).map((_, i) => (
            <div key={i} className="bg-white rounded-xl border border-stone-200 overflow-hidden animate-pulse">
              <div className="aspect-square bg-stone-200" />
              <div className="p-3 space-y-2">
                <div className="h-4 bg-stone-200 rounded w-3/4" />
                <div className="h-4 bg-stone-200 rounded w-1/2" />
              </div>
            </div>
          ))}
        </div>
      ) : filtered.length === 0 ? (
        <div className="text-center py-16 text-stone-400">
          <Package className="w-12 h-12 mx-auto mb-3" />
          <p>Không tìm thấy sản phẩm nào</p>
        </div>
      ) : (
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {filtered.map((p) => (
            <div key={p.id} className="bg-white rounded-xl border border-stone-200 overflow-hidden hover:shadow-lg transition-shadow flex flex-col">
              <div className="aspect-square bg-stone-100 overflow-hidden relative">
                <img src={p.image_url} alt={p.name} className="w-full h-full object-cover" />
                {p.stock <= 0 && (
                  <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
                    <span className="text-white font-semibold">Hết hàng</span>
                  </div>
                )}
                {p.stock > 0 && p.stock < 50 && (
                  <span className="absolute top-2 right-2 bg-rose-500 text-white text-xs px-2 py-1 rounded-lg">
                    Còn {formatNumber(p.stock)} {p.unit}
                  </span>
                )}
              </div>
              <div className="p-3 flex flex-col flex-1">
                <h3 className="font-semibold text-stone-800 text-sm mb-1">{p.name}</h3>
                <p className="text-xs text-stone-500 mb-2 line-clamp-2 flex-1">{p.description}</p>
                <p className="text-amber-700 font-bold mb-2">
                  {formatPrice(p.price)}
                  <span className="text-stone-400 text-xs font-normal">/{p.unit}</span>
                </p>

                {p.stock > 0 && (
                  <>
                    <div className="flex items-center gap-2 mb-2">
                      <button
                        onClick={() => setQty(p.id, getQty(p.id) - 1)}
                        className="w-8 h-8 rounded-lg border border-stone-200 flex items-center justify-center hover:bg-stone-50"
                      >
                        <Minus className="w-4 h-4" />
                      </button>
                      <input
                        type="number"
                        value={getQty(p.id)}
                        onChange={(e) => setQty(p.id, parseInt(e.target.value) || 1)}
                        className="w-12 text-center text-sm border border-stone-200 rounded-lg py-1"
                      />
                      <button
                        onClick={() => setQty(p.id, getQty(p.id) + 1)}
                        className="w-8 h-8 rounded-lg border border-stone-200 flex items-center justify-center hover:bg-stone-50"
                      >
                        <Plus className="w-4 h-4" />
                      </button>
                      <span className="text-xs text-stone-400">{p.unit}</span>
                    </div>
                    <button
                      onClick={() => handleAdd(p)}
                      className="w-full py-2 bg-amber-600 hover:bg-amber-500 text-white rounded-lg text-sm font-medium flex items-center justify-center gap-1.5 transition-colors"
                    >
                      <ShoppingCart className="w-4 h-4" /> Đặt hàng
                    </button>
                  </>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
