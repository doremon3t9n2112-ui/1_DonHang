import { useEffect, useState } from 'react';
import { Truck, ShieldCheck, Clock, Phone, ArrowRight, Package } from 'lucide-react';
import { supabase, type Category, type Product, formatPrice } from '../lib/supabase';
import { useRouter } from '../lib/router';

export function Home() {
  const [categories, setCategories] = useState<Category[]>([]);
  const [featured, setFeatured] = useState<Product[]>([]);
  const { navigate } = useRouter();

  useEffect(() => {
    (async () => {
      const [{ data: cats }, { data: prods }] = await Promise.all([
        supabase.from('categories').select('*').order('sort_order'),
        supabase.from('products').select('*, category:categories(*)').eq('is_active', true).limit(4),
      ]);
      setCategories(cats || []);
      setFeatured(prods || []);
    })();
  }, []);

  return (
    <div>
      {/* Hero */}
      <section className="relative bg-gradient-to-br from-stone-800 via-stone-900 to-amber-950 text-white overflow-hidden">
        <div className="absolute inset-0 opacity-10" style={{
          backgroundImage: 'url(https://images.pexels.com/photos/1078884/pexels-photo-1078884.jpeg)',
          backgroundSize: 'cover',
          backgroundPosition: 'center',
        }} />
        <div className="relative max-w-7xl mx-auto px-4 py-16 md:py-24">
          <div className="max-w-2xl">
            <h1 className="text-3xl md:text-5xl font-bold leading-tight mb-4">
              Vật Liệu Xây Dựng <span className="text-amber-400">Song Thịnh</span>
            </h1>
            <p className="text-lg text-stone-300 mb-8 leading-relaxed">
              Cát, đá, xi măng, gạch, sắt thép — cung cấp tận công trình. Giá rõ ràng, giao hàng nhanh, thanh toán linh hoạt.
            </p>
            <div className="flex flex-wrap gap-3">
              <button
                onClick={() => navigate('/products')}
                className="px-6 py-3 bg-amber-600 hover:bg-amber-500 rounded-xl font-semibold transition-colors flex items-center gap-2"
              >
                Xem sản phẩm <ArrowRight className="w-5 h-5" />
              </button>
              <a
                href="tel:0901234567"
                className="px-6 py-3 bg-white/10 hover:bg-white/20 rounded-xl font-semibold transition-colors flex items-center gap-2"
              >
                <Phone className="w-5 h-5" /> 0901 234 567
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="max-w-7xl mx-auto px-4 py-12">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {[
            { icon: Truck, title: 'Giao tận công trình', desc: 'Xe tải chở vật liệu đến tận nơi' },
            { icon: ShieldCheck, title: 'Giá rõ ràng', desc: 'Hiển thị giá theo bao, khối, tấn' },
            { icon: Clock, title: 'Theo dõi đơn hàng', desc: 'Cập nhật trạng thái realtime' },
            { icon: Phone, title: 'Tư vấn nhanh', desc: 'Zalo & Hotline 24/7' },
          ].map((f, i) => (
            <div key={i} className="bg-white rounded-xl p-5 border border-stone-200 hover:shadow-md transition-shadow">
              <div className="w-11 h-11 rounded-lg bg-amber-50 flex items-center justify-center mb-3">
                <f.icon className="w-6 h-6 text-amber-600" />
              </div>
              <h3 className="font-semibold text-stone-800 mb-1">{f.title}</h3>
              <p className="text-sm text-stone-500">{f.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Categories */}
      <section className="max-w-7xl mx-auto px-4 pb-12">
        <h2 className="text-2xl font-bold text-stone-800 mb-6">Danh mục sản phẩm</h2>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => navigate(`/products?cat=${cat.slug}`)}
              className="bg-white rounded-xl p-5 border border-stone-200 hover:border-amber-400 hover:shadow-md transition-all flex flex-col items-center gap-3 group"
            >
              <div className="w-14 h-14 rounded-full bg-gradient-to-br from-amber-100 to-orange-100 flex items-center justify-center group-hover:scale-110 transition-transform">
                <Package className="w-7 h-7 text-amber-700" />
              </div>
              <span className="font-medium text-stone-700 text-sm">{cat.name}</span>
            </button>
          ))}
        </div>
      </section>

      {/* Featured products */}
      <section className="max-w-7xl mx-auto px-4 pb-16">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold text-stone-800">Sản phẩm nổi bật</h2>
          <button onClick={() => navigate('/products')} className="text-amber-600 hover:text-amber-700 font-medium text-sm flex items-center gap-1">
            Xem tất cả <ArrowRight className="w-4 h-4" />
          </button>
        </div>
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {featured.map((p) => (
            <div
              key={p.id}
              onClick={() => navigate('/products')}
              className="bg-white rounded-xl overflow-hidden border border-stone-200 hover:shadow-lg transition-shadow cursor-pointer"
            >
              <div className="aspect-square bg-stone-100 overflow-hidden">
                <img src={p.image_url} alt={p.name} className="w-full h-full object-cover hover:scale-105 transition-transform duration-300" />
              </div>
              <div className="p-3">
                <h3 className="font-semibold text-stone-800 text-sm mb-1 line-clamp-1">{p.name}</h3>
                <p className="text-amber-700 font-bold">{formatPrice(p.price)}<span className="text-stone-400 text-xs font-normal">/{p.unit}</span></p>
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
