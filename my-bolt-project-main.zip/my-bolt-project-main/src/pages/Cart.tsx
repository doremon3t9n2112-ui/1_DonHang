import { Plus, Minus, Trash2, ShoppingCart, ArrowRight } from 'lucide-react';
import { useCart } from '../lib/cart';
import { formatPrice } from '../lib/supabase';
import { useRouter } from '../lib/router';

export function Cart() {
  const { items, updateQuantity, removeItem, subtotal, count } = useCart();
  const { navigate } = useRouter();

  if (items.length === 0) {
    return (
      <div className="max-w-3xl mx-auto px-4 py-16 text-center">
        <ShoppingCart className="w-16 h-16 text-stone-300 mx-auto mb-4" />
        <h2 className="text-xl font-semibold text-stone-700 mb-2">Giỏ hàng trống</h2>
        <p className="text-stone-500 mb-6">Hãy chọn vật liệu để đặt hàng</p>
        <button
          onClick={() => navigate('/products')}
          className="px-6 py-3 bg-amber-600 hover:bg-amber-500 text-white rounded-xl font-medium transition-colors"
        >
          Xem sản phẩm
        </button>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto px-4 py-6">
      <h1 className="text-2xl font-bold text-stone-800 mb-4">Giỏ hàng ({count} mặt hàng)</h1>

      <div className="space-y-3 mb-6">
        {items.map((item) => (
          <div key={item.product.id} className="bg-white rounded-xl border border-stone-200 p-4 flex gap-3">
            <div className="w-20 h-20 rounded-lg bg-stone-100 overflow-hidden flex-shrink-0">
              <img src={item.product.image_url} alt={item.product.name} className="w-full h-full object-cover" />
            </div>
            <div className="flex-1 min-w-0">
              <h3 className="font-semibold text-stone-800 text-sm">{item.product.name}</h3>
              <p className="text-amber-700 font-bold text-sm">
                {formatPrice(item.product.price)}<span className="text-stone-400 text-xs font-normal">/{item.product.unit}</span>
              </p>
              <div className="flex items-center gap-2 mt-2">
                <button
                  onClick={() => updateQuantity(item.product.id, item.quantity - 1)}
                  className="w-8 h-8 rounded-lg border border-stone-200 flex items-center justify-center hover:bg-stone-50"
                >
                  <Minus className="w-4 h-4" />
                </button>
                <input
                  type="number"
                  value={item.quantity}
                  onChange={(e) => updateQuantity(item.product.id, parseInt(e.target.value) || 0)}
                  className="w-14 text-center text-sm border border-stone-200 rounded-lg py-1"
                />
                <button
                  onClick={() => updateQuantity(item.product.id, item.quantity + 1)}
                  className="w-8 h-8 rounded-lg border border-stone-200 flex items-center justify-center hover:bg-stone-50"
                >
                  <Plus className="w-4 h-4" />
                </button>
                <span className="text-xs text-stone-400">{item.product.unit}</span>
                <button
                  onClick={() => removeItem(item.product.id)}
                  className="ml-auto p-2 text-rose-500 hover:bg-rose-50 rounded-lg"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
            <div className="text-right">
              <p className="font-bold text-stone-800">{formatPrice(item.product.price * item.quantity)}</p>
            </div>
          </div>
        ))}
      </div>

      <div className="bg-white rounded-xl border border-stone-200 p-4">
        <div className="flex justify-between items-center mb-4">
          <span className="text-stone-600">Tạm tính</span>
          <span className="font-bold text-stone-800">{formatPrice(subtotal)}</span>
        </div>
        <p className="text-xs text-stone-400 mb-4">Phí vận chuyển sẽ được tính ở bước thanh toán dựa trên khoảng cách và khối lượng.</p>
        <button
          onClick={() => navigate('/checkout')}
          className="w-full py-3 bg-amber-600 hover:bg-amber-500 text-white rounded-xl font-semibold flex items-center justify-center gap-2 transition-colors"
        >
          Tiến hành đặt hàng <ArrowRight className="w-5 h-5" />
        </button>
      </div>
    </div>
  );
}
