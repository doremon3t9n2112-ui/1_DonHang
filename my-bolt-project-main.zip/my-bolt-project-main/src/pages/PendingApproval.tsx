import { Clock, LogOut, ArrowLeft } from 'lucide-react';
import { useAuth } from '../lib/auth';
import { useRouter } from '../lib/router';

export function PendingApproval() {
  const { profile, signOut } = useAuth();
  const { navigate } = useRouter();

  return (
    <div className="max-w-md mx-auto px-4 py-12 text-center">
      <div className="w-20 h-20 rounded-full bg-amber-100 flex items-center justify-center mx-auto mb-6">
        <Clock className="w-10 h-10 text-amber-600" />
      </div>
      <h1 className="text-xl font-bold text-stone-800 mb-2">Đang chờ phê duyệt</h1>
      <p className="text-stone-500 mb-2">
        Tài khoản <span className="font-medium text-stone-700">{profile?.email}</span> đã được tạo
        và đang chờ chủ quản phê duyệt.
      </p>
      <p className="text-stone-400 text-sm mb-6">
        Vui lòng liên hệ chủ quản để được kích hoạt quyền truy cập.
      </p>
      <div className="flex justify-center gap-3">
        <button
          onClick={async () => { await signOut(); navigate('/'); }}
          className="px-6 py-3 bg-white border border-stone-200 hover:bg-stone-50 text-stone-700 rounded-xl font-medium flex items-center gap-2 transition-colors"
        >
          <LogOut className="w-5 h-5" /> Đăng xuất
        </button>
        <button
          onClick={() => navigate('/')}
          className="px-6 py-3 bg-amber-600 hover:bg-amber-500 text-white rounded-xl font-medium flex items-center gap-2 transition-colors"
        >
          <ArrowLeft className="w-5 h-5" /> Về trang chủ
        </button>
      </div>
    </div>
  );
}
