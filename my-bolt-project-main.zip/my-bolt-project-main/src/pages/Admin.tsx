import { useEffect, useState, useCallback } from 'react';
import {
  Bell, Package, Truck, CheckCircle2, Clock, XCircle, Phone, MapPin,
  TrendingUp, Boxes, ClipboardList, Edit3, Save, X, AlertCircle,
  Users, UserCheck, UserX, LogOut, Shield
} from 'lucide-react';
import {
  supabase, type Order, type OrderItem, type Product, type Category,
  type OrderStatus, STATUS_LABELS, STATUS_COLORS, PAYMENT_LABELS,
  formatPrice, formatNumber
} from '../lib/supabase';
import { useAuth, type Profile } from '../lib/auth';

type AdminTab = 'dashboard' | 'orders' | 'inventory' | 'users';

export function Admin() {
  const { profile, signOut } = useAuth();
  const [tab, setTab] = useState<AdminTab>('dashboard');
  const [orders, setOrders] = useState<(Order & { order_items: OrderItem[] })[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [users, setUsers] = useState<Profile[]>([]);
  const [loading, setLoading] = useState(true);
  const [newCount, setNewCount] = useState(0);
  const [selectedOrder, setSelectedOrder] = useState<string | null>(null);
  const [editingStock, setEditingStock] = useState<string | null>(null);
  const [stockValue, setStockValue] = useState('');
  const [notif, setNotif] = useState(false);

  const loadData = useCallback(async () => {
    const [{ data: ords }, { data: prods }, { data: cats }, { data: usrs }] = await Promise.all([
      supabase.from('orders').select('*, order_items(*)').order('created_at', { ascending: false }),
      supabase.from('products').select('*').order('name'),
      supabase.from('categories').select('*').order('sort_order'),
      supabase.from('profiles').select('*').order('created_at', { ascending: false }),
    ]);
    setOrders(ords || []);
    setProducts(prods || []);
    setCategories(cats || []);
    setUsers(usrs as Profile[] || []);
    setLoading(false);
  }, []);

  useEffect(() => {
    loadData();
    // Poll for new orders every 15 seconds
    const interval = setInterval(async () => {
      const { data: latest } = await supabase
        .from('orders')
        .select('id, status, created_at')
        .order('created_at', { ascending: false })
        .limit(1)
        .maybeSingle();
      if (latest && orders.length > 0 && latest.id !== orders[0]?.id) {
        setNotif(true);
        setTimeout(() => setNotif(false), 5000);
        loadData();
      }
    }, 15000);
    return () => clearInterval(interval);
  }, [loadData, orders]);

  useEffect(() => {
    setNewCount(orders.filter((o) => o.status === 'pending').length);
  }, [orders]);

  const updateStatus = async (orderId: string, status: OrderStatus) => {
    await supabase.from('orders').update({ status, updated_at: new Date().toISOString() }).eq('id', orderId);
    setOrders((prev) => prev.map((o) => (o.id === orderId ? { ...o, status } : o)));
  };

  const saveStock = async (productId: string) => {
    const val = parseFloat(stockValue) || 0;
    await supabase.from('products').update({ stock: val }).eq('id', productId);
    setProducts((prev) => prev.map((p) => (p.id === productId ? { ...p, stock: val } : p)));
    setEditingStock(null);
  };

  const stats = {
    total: orders.length,
    pending: orders.filter((o) => o.status === 'pending').length,
    delivering: orders.filter((o) => o.status === 'delivering').length,
    delivered: orders.filter((o) => o.status === 'delivered').length,
    revenue: orders.filter((o) => o.status === 'delivered').reduce((s, o) => s + o.total, 0),
    lowStock: products.filter((p) => p.stock < 50).length,
  };

  const tabs: { key: AdminTab; label: string; icon: typeof Package; badge?: number }[] = [
    { key: 'dashboard', label: 'Tổng quan', icon: TrendingUp },
    { key: 'orders', label: 'Đơn hàng', icon: ClipboardList, badge: newCount },
    { key: 'inventory', label: 'Kho hàng', icon: Boxes },
    ...(profile?.role === 'owner' ? [{ key: 'users' as AdminTab, label: 'Người dùng', icon: Users, badge: users.filter((u) => u.status === 'pending').length }] : []),
  ];

  const updateUserStatus = async (userId: string, status: 'approved' | 'rejected') => {
    await supabase.from('profiles').update({ status }).eq('id', userId);
    setUsers((prev) => prev.map((u) => (u.id === userId ? { ...u, status } : u)));
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-6">
      <div className="flex items-center gap-3 mb-6">
        <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-amber-600 to-orange-700 flex items-center justify-center">
          <span className="text-white font-bold">ST</span>
        </div>
        <div>
          <h1 className="text-xl font-bold text-stone-800">Quản lý Song Thịnh</h1>
          <p className="text-xs text-stone-500">Hệ thống quản lý đơn hàng & kho</p>
        </div>
        {notif && (
          <div className="ml-auto flex items-center gap-2 bg-amber-50 border border-amber-200 text-amber-700 px-3 py-1.5 rounded-lg text-sm animate-pulse">
            <Bell className="w-4 h-4" /> Đơn hàng mới!
          </div>
        )}
        <div className="ml-auto flex items-center gap-3">
          <div className="text-right hidden sm:block">
            <div className="text-sm font-medium text-stone-700">{profile?.full_name || profile?.email}</div>
            <div className="text-xs text-stone-400 flex items-center gap-1 justify-end">
              <Shield className="w-3 h-3" />
              {profile?.role === 'owner' ? 'Chủ quản' : 'Nhân viên'}
            </div>
          </div>
          <button
            onClick={async () => { await signOut(); }}
            className="p-2 rounded-lg border border-stone-200 text-stone-500 hover:bg-stone-50 transition-colors"
            title="Đăng xuất"
          >
            <LogOut className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-2 mb-6 overflow-x-auto pb-1">
        {tabs.map((t) => (
          <button
            key={t.key}
            onClick={() => setTab(t.key)}
            className={`px-4 py-2.5 rounded-lg font-medium text-sm flex items-center gap-2 whitespace-nowrap transition-colors ${
              tab === t.key ? 'bg-stone-800 text-white' : 'bg-white text-stone-600 border border-stone-200 hover:bg-stone-50'
            }`}
          >
            <t.icon className="w-4 h-4" />
            {t.label}
            {t.badge ? (
              <span className="bg-amber-500 text-white text-xs px-2 py-0.5 rounded-full">{t.badge}</span>
            ) : null}
          </button>
        ))}
      </div>

      {loading ? (
        <div className="text-center py-12 text-stone-400">Đang tải...</div>
      ) : (
        <>
          {/* Dashboard */}
          {tab === 'dashboard' && (
            <div>
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
                {[
                  { label: 'Tổng đơn', value: stats.total, icon: ClipboardList, color: 'text-stone-700', bg: 'bg-stone-100' },
                  { label: 'Chờ xác nhận', value: stats.pending, icon: Clock, color: 'text-amber-700', bg: 'bg-amber-100' },
                  { label: 'Đang giao', value: stats.delivering, icon: Truck, color: 'text-blue-700', bg: 'bg-blue-100' },
                  { label: 'Doanh thu', value: formatPrice(stats.revenue), icon: TrendingUp, color: 'text-emerald-700', bg: 'bg-emerald-100' },
                ].map((s, i) => (
                  <div key={i} className="bg-white rounded-xl border border-stone-200 p-4">
                    <div className={`w-10 h-10 rounded-lg ${s.bg} flex items-center justify-center mb-2`}>
                      <s.icon className={`w-5 h-5 ${s.color}`} />
                    </div>
                    <div className="text-2xl font-bold text-stone-800">{s.value}</div>
                    <div className="text-sm text-stone-500">{s.label}</div>
                  </div>
                ))}
              </div>

              {stats.lowStock > 0 && (
                <div className="bg-rose-50 border border-rose-200 rounded-xl p-4 mb-6 flex items-center gap-3">
                  <AlertCircle className="w-5 h-5 text-rose-600" />
                  <span className="text-rose-700 text-sm font-medium">
                    Có {stats.lowStock} sản phẩm sắp hết hàng. Kiểm tra và cập nhật kho.
                  </span>
                  <button onClick={() => setTab('inventory')} className="ml-auto text-sm text-rose-700 underline">
                    Xem kho
                  </button>
                </div>
              )}

              <div className="bg-white rounded-xl border border-stone-200 p-4">
                <h2 className="font-semibold text-stone-800 mb-3">Đơn hàng gần đây</h2>
                <div className="space-y-2">
                  {orders.slice(0, 5).map((o) => (
                    <div key={o.id} className="flex items-center justify-between py-2 border-b border-stone-100 last:border-0">
                      <div>
                        <span className="font-medium text-stone-800 text-sm">{o.order_code}</span>
                        <span className="text-stone-400 text-sm ml-2">{o.customer_name}</span>
                      </div>
                      <span className={`px-2.5 py-1 rounded-full text-xs font-medium border ${STATUS_COLORS[o.status]}`}>
                        {STATUS_LABELS[o.status]}
                      </span>
                    </div>
                  ))}
                  {orders.length === 0 && <p className="text-stone-400 text-sm">Chưa có đơn hàng nào.</p>}
                </div>
              </div>
            </div>
          )}

          {/* Orders */}
          {tab === 'orders' && (
            <div>
              {orders.length === 0 ? (
                <div className="text-center py-12 text-stone-400">
                  <ClipboardList className="w-12 h-12 mx-auto mb-3" />
                  <p>Chưa có đơn hàng nào.</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {orders.map((order) => (
                    <div key={order.id} className="bg-white rounded-xl border border-stone-200 overflow-hidden">
                      <div
                        className="p-4 cursor-pointer"
                        onClick={() => setSelectedOrder(selectedOrder === order.id ? null : order.id)}
                      >
                        <div className="flex items-center justify-between mb-2">
                          <div className="flex items-center gap-2">
                            <span className="font-bold text-stone-800">{order.order_code}</span>
                            <span className={`px-2.5 py-0.5 rounded-full text-xs font-medium border ${STATUS_COLORS[order.status]}`}>
                              {STATUS_LABELS[order.status]}
                            </span>
                          </div>
                          <span className="text-stone-400 text-sm">
                            {new Date(order.created_at).toLocaleString('vi-VN')}
                          </span>
                        </div>
                        <div className="flex items-center gap-4 text-sm text-stone-600">
                          <span className="font-medium">{order.customer_name}</span>
                          <a href={`tel:${order.customer_phone}`} className="flex items-center gap-1 text-blue-600 hover:underline">
                            <Phone className="w-3.5 h-3.5" /> {order.customer_phone}
                          </a>
                          <span className="hidden md:flex items-center gap-1">
                            <MapPin className="w-3.5 h-3.5" /> {order.address.slice(0, 40)}...
                          </span>
                          <span className="font-bold text-amber-700 ml-auto">{formatPrice(order.total)}</span>
                        </div>
                      </div>

                      {selectedOrder === order.id && (
                        <div className="border-t border-stone-100 p-4 bg-stone-50">
                          <div className="grid md:grid-cols-2 gap-4 mb-4">
                            <div>
                              <h3 className="font-semibold text-stone-700 text-sm mb-2">Thông tin giao hàng</h3>
                              <div className="space-y-1 text-sm text-stone-600">
                                <p><span className="font-medium">Họ tên:</span> {order.customer_name}</p>
                                <p><span className="font-medium">Điện thoại:</span> {order.customer_phone}</p>
                                <p className="flex items-start gap-1"><MapPin className="w-4 h-4 mt-0.5 flex-shrink-0" /> {order.address}</p>
                                {order.notes && <p><span className="font-medium">Ghi chú:</span> {order.notes}</p>}
                                <p><span className="font-medium">Thanh toán:</span> {PAYMENT_LABELS[order.payment_method]}</p>
                                {order.distance_km && <p><span className="font-medium">Khoảng cách:</span> {order.distance_km.toFixed(1)} km</p>}
                                {order.lat && order.lng && (
                                  <a href={`https://www.google.com/maps?q=${order.lat},${order.lng}`} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1 text-blue-600 hover:underline mt-1">
                                    <MapPin className="w-4 h-4" /> Xem vị trí trên bản đồ
                                  </a>
                                )}
                              </div>
                            </div>
                            <div>
                              <h3 className="font-semibold text-stone-700 text-sm mb-2">Chi tiết vật liệu</h3>
                              <div className="space-y-1 text-sm">
                                {order.order_items.map((item) => (
                                  <div key={item.id} className="flex justify-between">
                                    <span className="text-stone-600">{item.product_name} × {item.quantity} {item.unit}</span>
                                    <span className="text-stone-800">{formatPrice(item.price * item.quantity)}</span>
                                  </div>
                                ))}
                                <div className="border-t border-stone-200 pt-1 mt-1 space-y-0.5">
                                  <div className="flex justify-between text-stone-500"><span>Tạm tính</span><span>{formatPrice(order.subtotal)}</span></div>
                                  <div className="flex justify-between text-stone-500"><span>Phí vận chuyển</span><span>{formatPrice(order.shipping_fee)}</span></div>
                                  <div className="flex justify-between font-bold text-stone-800"><span>Tổng</span><span className="text-amber-700">{formatPrice(order.total)}</span></div>
                                </div>
                              </div>
                            </div>
                          </div>

                          {/* Status controls */}
                          {order.status !== 'cancelled' && order.status !== 'delivered' && (
                            <div>
                              <h3 className="font-semibold text-stone-700 text-sm mb-2">Cập nhật trạng thái</h3>
                              <div className="flex flex-wrap gap-2">
                                {([
                                  { key: 'pending', label: 'Chờ xác nhận', icon: Clock },
                                  { key: 'confirmed', label: 'Đã xác nhận', icon: Package },
                                  { key: 'delivering', label: 'Đang giao', icon: Truck },
                                  { key: 'delivered', label: 'Đã giao', icon: CheckCircle2 },
                                ] as const).map((s) => (
                                  <button
                                    key={s.key}
                                    onClick={() => updateStatus(order.id, s.key)}
                                    className={`px-3 py-2 rounded-lg text-sm font-medium border flex items-center gap-1.5 transition-colors ${
                                      order.status === s.key
                                        ? 'bg-amber-600 text-white border-amber-600'
                                        : 'bg-white text-stone-600 border-stone-200 hover:border-amber-300'
                                    }`}
                                  >
                                    <s.icon className="w-4 h-4" /> {s.label}
                                  </button>
                                ))}
                                <button
                                  onClick={() => updateStatus(order.id, 'cancelled')}
                                  className="px-3 py-2 rounded-lg text-sm font-medium border bg-white text-rose-600 border-rose-200 hover:bg-rose-50 flex items-center gap-1.5 transition-colors"
                                >
                                  <XCircle className="w-4 h-4" /> Hủy đơn
                                </button>
                              </div>
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* Inventory */}
          {tab === 'inventory' && (
            <div>
              <div className="bg-white rounded-xl border border-stone-200 overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead className="bg-stone-50 border-b border-stone-200">
                      <tr>
                        <th className="text-left px-4 py-3 text-sm font-semibold text-stone-700">Sản phẩm</th>
                        <th className="text-left px-4 py-3 text-sm font-semibold text-stone-700 hidden md:table-cell">Danh mục</th>
                        <th className="text-right px-4 py-3 text-sm font-semibold text-stone-700">Giá</th>
                        <th className="text-right px-4 py-3 text-sm font-semibold text-stone-700">Tồn kho</th>
                        <th className="text-center px-4 py-3 text-sm font-semibold text-stone-700">Thao tác</th>
                      </tr>
                    </thead>
                    <tbody>
                      {products.map((p) => {
                        const cat = categories.find((c) => c.id === p.category_id);
                        const lowStock = p.stock < 50;
                        return (
                          <tr key={p.id} className="border-b border-stone-100 last:border-0">
                            <td className="px-4 py-3">
                              <div className="flex items-center gap-2">
                                <div className="w-10 h-10 rounded-lg bg-stone-100 overflow-hidden flex-shrink-0">
                                  <img src={p.image_url} alt={p.name} className="w-full h-full object-cover" />
                                </div>
                                <span className="font-medium text-stone-800 text-sm">{p.name}</span>
                              </div>
                            </td>
                            <td className="px-4 py-3 text-sm text-stone-500 hidden md:table-cell">{cat?.name || '-'}</td>
                            <td className="px-4 py-3 text-right text-sm text-stone-700">
                              {formatPrice(p.price)}<span className="text-stone-400">/{p.unit}</span>
                            </td>
                            <td className="px-4 py-3 text-right">
                              {editingStock === p.id ? (
                                <div className="flex items-center gap-1 justify-end">
                                  <input
                                    type="number"
                                    value={stockValue}
                                    onChange={(e) => setStockValue(e.target.value)}
                                    className="w-20 px-2 py-1 text-sm border border-stone-200 rounded text-right"
                                    autoFocus
                                  />
                                  <button onClick={() => saveStock(p.id)} className="p-1 text-emerald-600 hover:bg-emerald-50 rounded">
                                    <Save className="w-4 h-4" />
                                  </button>
                                  <button onClick={() => setEditingStock(null)} className="p-1 text-stone-400 hover:bg-stone-100 rounded">
                                    <X className="w-4 h-4" />
                                  </button>
                                </div>
                              ) : (
                                <span className={`font-medium ${lowStock ? 'text-rose-600' : 'text-stone-700'}`}>
                                  {formatNumber(p.stock)} {p.unit}
                                </span>
                              )}
                            </td>
                            <td className="px-4 py-3 text-center">
                              {editingStock !== p.id && (
                                <button
                                  onClick={() => {
                                    setEditingStock(p.id);
                                    setStockValue(String(p.stock));
                                  }}
                                  className="p-2 text-stone-500 hover:bg-stone-100 rounded-lg"
                                >
                                  <Edit3 className="w-4 h-4" />
                                </button>
                              )}
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* Users (owner only) */}
          {tab === 'users' && profile?.role === 'owner' && (
            <div>
              <div className="bg-white rounded-xl border border-stone-200 overflow-hidden">
                <div className="p-4 border-b border-stone-100">
                  <h2 className="font-semibold text-stone-800">Quản lý người dùng</h2>
                  <p className="text-sm text-stone-500 mt-1">Phê duyệt hoặc từ chối tài khoản nhân viên</p>
                </div>
                <div className="divide-y divide-stone-100">
                  {users.length === 0 ? (
                    <p className="text-stone-400 text-sm p-4 text-center">Chưa có người dùng nào.</p>
                  ) : (
                    users.map((u) => (
                      <div key={u.id} className="p-4 flex items-center gap-3 flex-wrap">
                        <div className="w-10 h-10 rounded-full bg-stone-100 flex items-center justify-center flex-shrink-0">
                          {u.role === 'owner' ? (
                            <Shield className="w-5 h-5 text-amber-600" />
                          ) : (
                            <Users className="w-5 h-5 text-stone-400" />
                          )}
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 flex-wrap">
                            <span className="font-medium text-stone-800 text-sm">{u.full_name || u.email}</span>
                            {u.role === 'owner' && (
                              <span className="px-2 py-0.5 rounded-full text-xs font-medium bg-amber-100 text-amber-700 border border-amber-200">
                                Chủ quản
                              </span>
                            )}
                            {u.status === 'pending' && (
                              <span className="px-2 py-0.5 rounded-full text-xs font-medium bg-amber-50 text-amber-600 border border-amber-200">
                                Chờ duyệt
                              </span>
                            )}
                            {u.status === 'approved' && (
                              <span className="px-2 py-0.5 rounded-full text-xs font-medium bg-emerald-50 text-emerald-600 border border-emerald-200">
                                Đã duyệt
                              </span>
                            )}
                            {u.status === 'rejected' && (
                              <span className="px-2 py-0.5 rounded-full text-xs font-medium bg-rose-50 text-rose-600 border border-rose-200">
                                Từ chối
                              </span>
                            )}
                          </div>
                          <div className="text-xs text-stone-400 mt-0.5">{u.email}</div>
                          <div className="text-xs text-stone-400">
                            Đăng ký: {new Date(u.created_at).toLocaleDateString('vi-VN')}
                          </div>
                        </div>
                        {u.role !== 'owner' && u.status !== 'approved' && (
                          <button
                            onClick={() => updateUserStatus(u.id, 'approved')}
                            className="px-3 py-2 rounded-lg text-sm font-medium bg-emerald-50 text-emerald-700 border border-emerald-200 hover:bg-emerald-100 flex items-center gap-1.5 transition-colors"
                          >
                            <UserCheck className="w-4 h-4" /> Duyệt
                          </button>
                        )}
                        {u.role !== 'owner' && u.status !== 'rejected' && (
                          <button
                            onClick={() => updateUserStatus(u.id, 'rejected')}
                            className="px-3 py-2 rounded-lg text-sm font-medium bg-rose-50 text-rose-700 border border-rose-200 hover:bg-rose-100 flex items-center gap-1.5 transition-colors"
                          >
                            <UserX className="w-4 h-4" /> Từ chối
                          </button>
                        )}
                      </div>
                    ))
                  )}
                </div>
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
}
