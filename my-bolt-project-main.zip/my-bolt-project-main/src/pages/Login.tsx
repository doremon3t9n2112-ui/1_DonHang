import { useState } from 'react';
import { Loader2, Lock, Mail, User, ArrowLeft } from 'lucide-react';
import { useAuth } from '../lib/auth';
import { useRouter } from '../lib/router';

export function Login() {
  const { signIn, signUp } = useAuth();
  const { navigate } = useRouter();
  const [mode, setMode] = useState<'login' | 'signup'>('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [fullName, setFullName] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [signedUp, setSignedUp] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    if (mode === 'login') {
      const { error } = await signIn(email, password);
      if (error) {
        setError(error);
        setLoading(false);
      }
    } else {
      if (!fullName.trim()) {
        setError('Vui lòng nhập họ tên');
        setLoading(false);
        return;
      }
      if (password.length < 6) {
        setError('Mật khẩu phải có ít nhất 6 ký tự');
        setLoading(false);
        return;
      }
      const { error } = await signUp(email, password, fullName);
      if (error) {
        setError(error);
        setLoading(false);
      } else {
        setSignedUp(true);
        setLoading(false);
      }
    }
  };

  if (signedUp) {
    return (
      <div className="max-w-md mx-auto px-4 py-12 text-center">
        <div className="w-16 h-16 rounded-full bg-amber-100 flex items-center justify-center mx-auto mb-4">
          <Mail className="w-8 h-8 text-amber-600" />
        </div>
        <h1 className="text-xl font-bold text-stone-800 mb-2">Đăng ký thành công</h1>
        <p className="text-stone-500 mb-6">
          Tài khoản của bạn đã được tạo. Vui lòng đăng nhập để tiếp tục.
          Nếu bạn không phải là chủ quản, tài khoản cần được chủ quản phê duyệt.
        </p>
        <button
          onClick={() => {
            setSignedUp(false);
            setMode('login');
          }}
          className="px-6 py-3 bg-amber-600 hover:bg-amber-500 text-white rounded-xl font-medium transition-colors"
        >
          Đăng nhập
        </button>
      </div>
    );
  }

  return (
    <div className="max-w-md mx-auto px-4 py-8">
      <button onClick={() => navigate('/')} className="text-stone-500 hover:text-stone-700 flex items-center gap-1 text-sm mb-6">
        <ArrowLeft className="w-4 h-4" /> Về trang chủ
      </button>

      <div className="bg-white rounded-2xl border border-stone-200 shadow-sm p-6">
        <div className="flex items-center gap-2 mb-6">
          <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-amber-600 to-orange-700 flex items-center justify-center">
            <Lock className="w-5 h-5 text-white" />
          </div>
          <div>
            <h1 className="text-lg font-bold text-stone-800">
              {mode === 'login' ? 'Đăng nhập quản lý' : 'Đăng ký tài khoản'}
            </h1>
            <p className="text-xs text-stone-500">Song Thịnh — Vật liệu xây dựng</p>
          </div>
        </div>

        {error && (
          <div className="mb-4 bg-rose-50 border border-rose-200 text-rose-700 rounded-lg p-3 text-sm">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-3">
          {mode === 'signup' && (
            <div>
              <label className="text-sm text-stone-600 mb-1 block">Họ tên</label>
              <div className="relative">
                <User className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-stone-400" />
                <input
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  placeholder="Nguyễn Văn A"
                  className="w-full pl-10 pr-3 py-2.5 rounded-lg border border-stone-200 focus:border-amber-400 focus:ring-2 focus:ring-amber-100 outline-none"
                />
              </div>
            </div>
          )}

          <div>
            <label className="text-sm text-stone-600 mb-1 block">Email</label>
            <div className="relative">
              <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-stone-400" />
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="admin@songthinh.vn"
                required
                className="w-full pl-10 pr-3 py-2.5 rounded-lg border border-stone-200 focus:border-amber-400 focus:ring-2 focus:ring-amber-100 outline-none"
              />
            </div>
          </div>

          <div>
            <label className="text-sm text-stone-600 mb-1 block">Mật khẩu</label>
            <div className="relative">
              <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-stone-400" />
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                required
                className="w-full pl-10 pr-3 py-2.5 rounded-lg border border-stone-200 focus:border-amber-400 focus:ring-2 focus:ring-amber-100 outline-none"
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full py-3 bg-amber-600 hover:bg-amber-500 text-white rounded-xl font-semibold flex items-center justify-center gap-2 transition-colors disabled:opacity-50"
          >
            {loading && <Loader2 className="w-5 h-5 animate-spin" />}
            {mode === 'login' ? 'Đăng nhập' : 'Đăng ký'}
          </button>
        </form>

        <div className="mt-4 text-center text-sm text-stone-500">
          {mode === 'login' ? (
            <>
              Chưa có tài khoản?{' '}
              <button onClick={() => { setMode('signup'); setError(''); }} className="text-amber-600 hover:text-amber-700 font-medium">
                Đăng ký
              </button>
            </>
          ) : (
            <>
              Đã có tài khoản?{' '}
              <button onClick={() => { setMode('login'); setError(''); }} className="text-amber-600 hover:text-amber-700 font-medium">
                Đăng nhập
              </button>
            </>
          )}
        </div>
      </div>

      <p className="text-center text-xs text-stone-400 mt-4">
        Người dùng đầu tiên đăng ký sẽ tự động trở thành chủ quản (owner).
      </p>
    </div>
  );
}
