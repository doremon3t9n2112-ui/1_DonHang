import { useState } from 'react';
import { Search, MapPin, Clock, Package, Truck, CheckCircle2, XCircle, Loader2 } from 'lucide-react';
import { supabase, type Order, type OrderItem, STATUS_LABELS, STATUS_COLORS, formatPrice } from '../lib/supabase';

const STATUS_STEPS: { key: string; label: string; icon: typeof Package }[] = [
  { key: 'pending', label: 'Chờ xác nhận', icon: Clock },
  { key: 'confirmed', label: 'Đã xác nhận', icon: Package },
  { key: 'delivering', label: 'Đang giao', icon: Truck },
  { key: 'delivered', label: 'Đã giao', icon: CheckCircle2 },
];

export function Track() {
  const [phone, setPhone] = useState('');
  const [code, setCode] = useState('');
  const [orders, setOrders] = useState<(Order & { order_items: OrderItem[] })[]>([]);
  const [loading, setLoading] = useState(false);
  const [searched, setSearched] = useState(false);

  const search = async () => {
    if (!phone.trim()) return;
    setLoading(true);
    setSearched(true);

    let query = supabase.from('orders').select('*, order_items(*)').ilike('customer_phone', `%${phone.trim()}%`);
    if (code.trim()) {
      query = query.ilike('order_code', `%${code.trim()}%`);
    }
    query = query.order('created_at', { ascending: false });

    const { data } = await query;
    setOrders(data || []);
    setLoading(false);
  };

  const getStepIndex = (status: string) => {
    if (status === 'cancelled') return -1;
    return STATUS_STEPS.findIndex((s) => s.key === status);
  };

  return (
    <div className="max-w-3xl mx-auto px-4 py-6">
      <h1 className="text-2xl font-bold text-stone-800 mb-4">Theo dõi đơn hàng</h1>

      <div className="bg-white rounded-xl border border-stone-200 p-4 mb-6">
        <div className="grid md:grid-cols-2 gap-3 mb-3">
          <div>
            <label className="text-sm text-stone-600 mb-1 block">Số điện thoại *</label>
            <input
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              placeholder="0901 234 567"
              className="w-full px-3 py-2.5 rounded-lg border border-stone-200 focus:border-amber-400 focus:ring-2 focus:ring-amber-100 outline-none"
            />
          </div>
          <div>
            <label className="text-sm text-stone-600 mb-1 block">Mã đơn hàng (tùy chọn)</label>
            <input
              value={code}
              onChange={(e) => setCode(e.target.value)}
              placeholder="ST-123456"
              className="w-full px-3 py-2.5 rounded-lg border border-stone-200 focus:border-amber-400 focus:ring-2 focus:ring-amber-100 outline-none"
            />
          </div>
        </div>
        <button
          onClick={search}
          disabled={loading || !phone.trim()}
          className="w-full py-2.5 bg-amber-600 hover:bg-amber-500 text-white rounded-lg font-medium flex items-center justify-center gap-2 transition-colors disabled:opacity-50"
        >
          {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : <Search className="w-5 h-5" />}
          Tìm đơn hàng
        </button>
      </div>

      {searched && !loading && orders.length === 0 && (
        <div className="text-center py-12 text-stone-400">
          <Package className="w-12 h-12 mx-auto mb-3" />
          <p>Không tìm thấy đơn hàng nào với thông tin trên.</p>
        </div>
      )}

      <div className="space-y-4">
        {orders.map((order) => {
          const stepIndex = getStepIndex(order.status);
          return (
            <div key={order.id} className="bg-white rounded-xl border border-stone-200 p-4">
              <div className="flex items-center justify-between mb-3">
                <div>
                  <span className="font-bold text-stone-800">{order.order_code}</span>
                  <span className="text-stone-400 text-sm ml-2">
                    {new Date(order.created_at).toLocaleDateString('vi-VN')}
                  </span>
                </div>
                <span className={`px-3 py-1 rounded-full text-xs font-medium border ${STATUS_COLORS[order.status]}`}>
                  {STATUS_LABELS[order.status]}
                </span>
              </div>

              {order.status === 'cancelled' ? (
                <div className="flex items-center gap-2 text-rose-600 py-3">
                  <XCircle className="w-5 h-5" />
                  <span className="font-medium">Đơn hàng đã bị hủy</span>
                </div>
              ) : (
                <div className="flex items-center justify-between mb-4 px-2">
                  {STATUS_STEPS.map((step, i) => (
                    <div key={step.key} className="flex flex-col items-center flex-1 relative">
                      {i < STATUS_STEPS.length - 1 && (
                        <div className={`absolute top-5 left-1/2 w-full h-0.5 ${i < stepIndex ? 'bg-amber-500' : 'bg-stone-200'}`} />
                      )}
                      <div className={`w-10 h-10 rounded-full flex items-center justify-center z-10 relative ${
                        i <= stepIndex ? 'bg-amber-500 text-white' : 'bg-stone-100 text-stone-400'
                      }`}>
                        <step.icon className="w-5 h-5" />
                      </div>
                      <span className={`text-xs mt-1 text-center ${i <= stepIndex ? 'text-stone-700 font-medium' : 'text-stone-400'}`}>
                        {step.label}
                      </span>
                    </div>
                  ))}
                </div>
              )}

              <div className="space-y-1 mb-3">
                {order.order_items.map((item) => (
                  <div key={item.id} className="flex justify-between text-sm">
                    <span className="text-stone-600">{item.product_name} × {item.quantity} {item.unit}</span>
                    <span className="text-stone-800">{formatPrice(item.price * item.quantity)}</span>
                  </div>
                ))}
              </div>

              <div className="border-t border-stone-100 pt-3 space-y-1 text-sm">
                <div className="flex items-start gap-2 text-stone-600">
                  <MapPin className="w-4 h-4 mt-0.5 flex-shrink-0" />
                  <span>{order.address}</span>
                </div>
                {order.notes && (
                  <div className="flex items-start gap-2 text-stone-600">
                    <Package className="w-4 h-4 mt-0.5 flex-shrink-0" />
                    <span>{order.notes}</span>
                  </div>
                )}
                <div className="flex justify-between font-bold text-stone-800 pt-1">
                  <span>Tổng cộng</span>
                  <span className="text-amber-700">{formatPrice(order.total)}</span>
                </div>
              </div>

              {order.lat && order.lng && (
                <a
                  href={`https://www.google.com/maps?q=${order.lat},${order.lng}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="mt-3 inline-flex items-center gap-1.5 text-sm text-blue-600 hover:text-blue-700"
                >
                  <MapPin className="w-4 h-4" /> Xem vị trí trên bản đồ
                </a>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
