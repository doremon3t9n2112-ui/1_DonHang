import { useState } from 'react';
import { MapPin, Navigation, Truck, CreditCard, Banknote, Wallet, CheckCircle2, Loader2 } from 'lucide-react';
import { useCart } from '../lib/cart';
import { supabase, formatPrice, type PaymentMethod } from '../lib/supabase';
import { useRouter } from '../lib/router';

// Shop location (Song Thịnh) - default coordinates for demo
const SHOP_LAT = 10.762622;
const SHOP_LNG = 106.660172;

// Haversine distance in km
function haversine(lat1: number, lng1: number, lat2: number, lng2: number): number {
  const R = 6371;
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLng = ((lng2 - lng1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos((lat1 * Math.PI) / 180) * Math.cos((lat2 * Math.PI) / 180) * Math.sin(dLng / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

// Shipping: base fee + per km rate, scaled by total weight volume
function calcShipping(distanceKm: number, subtotal: number): number {
  if (distanceKm <= 0) return 0;
  const baseFee = 50000;
  const perKm = 8000;
  // Large orders (over 5 million) get free shipping within 20km
  if (subtotal >= 5000000 && distanceKm <= 20) return 0;
  return Math.round(baseFee + distanceKm * perKm);
}

export function Checkout() {
  const { items, subtotal, clear } = useCart();
  const { navigate } = useRouter();
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [address, setAddress] = useState('');
  const [lat, setLat] = useState<number | null>(null);
  const [lng, setLng] = useState<number | null>(null);
  const [notes, setNotes] = useState('');
  const [payment, setPayment] = useState<PaymentMethod>('cod');
  const [locating, setLocating] = useState(false);
  const [placing, setPlacing] = useState(false);
  const [error, setError] = useState('');

  const distance = lat !== null && lng !== null ? haversine(SHOP_LAT, SHOP_LNG, lat, lng) : 0;
  const shippingFee = calcShipping(distance, subtotal);
  const total = subtotal + shippingFee;

  const pinLocation = () => {
    setLocating(true);
    setError('');
    if (!navigator.geolocation) {
      setError('Trình duyệt không hỗ trợ định vị. Vui lòng nhập địa chỉ chi tiết.');
      setLocating(false);
      return;
    }
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setLat(pos.coords.latitude);
        setLng(pos.coords.longitude);
        setLocating(false);
      },
      () => {
        setError('Không lấy được vị trí. Vui lòng cho phép truy cập vị trí hoặc nhập địa chỉ chi tiết.');
        setLocating(false);
      },
      { enableHighAccuracy: true, timeout: 10000 }
    );
  };

  const useMapLink = () => {
    // Open Google Maps so user can find their location and paste coordinates
    window.open('https://www.google.com/maps', '_blank');
  };

  const validate = () => {
    if (!name.trim()) return 'Vui lòng nhập họ tên';
    if (!phone.trim()) return 'Vui lòng nhập số điện thoại';
    if (!/^[0-9+\s-]{8,15}$/.test(phone.trim())) return 'Số điện thoại không hợp lệ';
    if (!address.trim()) return 'Vui lòng nhập địa chỉ công trình';
    return '';
  };

  const placeOrder = async () => {
    const err = validate();
    if (err) {
      setError(err);
      return;
    }
    setPlacing(true);
    setError('');

    try {
      // Generate order code
      const orderCode = 'ST-' + Date.now().toString().slice(-6);

      const { data: order, error: orderError } = await supabase
        .from('orders')
        .insert({
          order_code: orderCode,
          customer_name: name.trim(),
          customer_phone: phone.trim(),
          address: address.trim(),
          lat,
          lng,
          notes: notes.trim(),
          status: 'pending',
          payment_method: payment,
          subtotal,
          shipping_fee: shippingFee,
          total,
          distance_km: distance || null,
        })
        .select()
        .single();

      if (orderError || !order) {
        setError('Không thể tạo đơn hàng. Vui lòng thử lại.');
        setPlacing(false);
        return;
      }

      const orderItems = items.map((item) => ({
        order_id: order.id,
        product_id: item.product.id,
        product_name: item.product.name,
        quantity: item.quantity,
        unit: item.product.unit,
        price: item.product.price,
      }));

      const { error: itemsError } = await supabase.from('order_items').insert(orderItems);
      if (itemsError) {
        setError('Đã tạo đơn hàng nhưng lỗi khi lưu chi tiết. Vui lòng liên hệ shop.');
        setPlacing(false);
        return;
      }

      clear();
      navigate(`/order-success?code=${orderCode}`);
    } catch {
      setError('Có lỗi xảy ra. Vui lòng thử lại.');
    }
    setPlacing(false);
  };

  if (items.length === 0) {
    return (
      <div className="max-w-3xl mx-auto px-4 py-16 text-center">
        <p className="text-stone-500 mb-4">Giỏ hàng trống</p>
        <button onClick={() => navigate('/products')} className="px-6 py-3 bg-amber-600 text-white rounded-xl font-medium">
          Xem sản phẩm
        </button>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto px-4 py-6">
      <h1 className="text-2xl font-bold text-stone-800 mb-4">Đặt hàng</h1>

      {error && (
        <div className="mb-4 bg-rose-50 border border-rose-200 text-rose-700 rounded-lg p-3 text-sm">
          {error}
        </div>
      )}

      <div className="space-y-4">
        {/* Customer info */}
        <div className="bg-white rounded-xl border border-stone-200 p-4">
          <h2 className="font-semibold text-stone-800 mb-3">Thông tin liên hệ</h2>
          <div className="grid md:grid-cols-2 gap-3">
            <div>
              <label className="text-sm text-stone-600 mb-1 block">Họ tên *</label>
              <input
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Nguyễn Văn A"
                className="w-full px-3 py-2.5 rounded-lg border border-stone-200 focus:border-amber-400 focus:ring-2 focus:ring-amber-100 outline-none"
              />
            </div>
            <div>
              <label className="text-sm text-stone-600 mb-1 block">Số điện thoại *</label>
              <input
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="0901 234 567"
                className="w-full px-3 py-2.5 rounded-lg border border-stone-200 focus:border-amber-400 focus:ring-2 focus:ring-amber-100 outline-none"
              />
            </div>
          </div>
        </div>

        {/* Delivery address + map */}
        <div className="bg-white rounded-xl border border-stone-200 p-4">
          <h2 className="font-semibold text-stone-800 mb-3">Địa chỉ công trình</h2>
          <label className="text-sm text-stone-600 mb-1 block">Địa chỉ chi tiết *</label>
          <textarea
            value={address}
            onChange={(e) => setAddress(e.target.value)}
            placeholder="Số nhà, đường, phường/xã, quận/huyện, tỉnh/thành"
            rows={2}
            className="w-full px-3 py-2.5 rounded-lg border border-stone-200 focus:border-amber-400 focus:ring-2 focus:ring-amber-100 outline-none mb-3"
          />

          <div className="flex flex-wrap gap-2 mb-3">
            <button
              onClick={pinLocation}
              disabled={locating}
              className="px-4 py-2.5 bg-amber-50 text-amber-700 border border-amber-200 rounded-lg text-sm font-medium flex items-center gap-2 hover:bg-amber-100 transition-colors disabled:opacity-50"
            >
              {locating ? <Loader2 className="w-4 h-4 animate-spin" /> : <MapPin className="w-4 h-4" />}
              Ghim vị trí của tôi
            </button>
            <button
              onClick={useMapLink}
              className="px-4 py-2.5 bg-blue-50 text-blue-700 border border-blue-200 rounded-lg text-sm font-medium flex items-center gap-2 hover:bg-blue-100 transition-colors"
            >
              <Navigation className="w-4 h-4" /> Mở Google Maps
            </button>
          </div>

          {lat !== null && lng !== null && (
            <div className="bg-emerald-50 border border-emerald-200 rounded-lg p-3 text-sm text-emerald-700 flex items-center gap-2">
              <CheckCircle2 className="w-5 h-5" />
              Đã ghim vị trí: {lat.toFixed(5)}, {lng.toFixed(5)}
              {distance > 0 && <span className="ml-2">· Khoảng cách: {distance.toFixed(1)} km</span>}
            </div>
          )}

          <p className="text-xs text-stone-400 mt-2">
            Ghim vị trí giúp xe chở vật liệu tìm đường đến công trình dễ hơn.
          </p>

          <div className="mt-3">
            <label className="text-sm text-stone-600 mb-1 block">Ghi chú đơn hàng</label>
            <textarea
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder='Ví dụ: "Giao sau 5h chiều", "Đường nhỏ xe 5 tấn không vào được"'
              rows={2}
              className="w-full px-3 py-2.5 rounded-lg border border-stone-200 focus:border-amber-400 focus:ring-2 focus:ring-amber-100 outline-none"
            />
          </div>
        </div>

        {/* Payment method */}
        <div className="bg-white rounded-xl border border-stone-200 p-4">
          <h2 className="font-semibold text-stone-800 mb-3">Phương thức thanh toán</h2>
          <div className="space-y-2">
            {[
              { value: 'cod', label: 'Thanh toán khi nhận hàng (COD)', desc: 'Tiền mặt hoặc chuyển khoản tại công trình', icon: Banknote },
              { value: 'deposit', label: 'Đặt cọc trước một phần', desc: 'Chuyển khoản ngân hàng cho đơn hàng lớn', icon: Wallet },
              { value: 'bank_transfer', label: 'Chuyển khoản ngân hàng', desc: 'Thanh toán toàn bộ trước khi giao', icon: CreditCard },
            ].map((opt) => (
              <button
                key={opt.value}
                onClick={() => setPayment(opt.value as PaymentMethod)}
                className={`w-full text-left p-3 rounded-lg border-2 transition-colors flex items-center gap-3 ${
                  payment === opt.value ? 'border-amber-500 bg-amber-50' : 'border-stone-200 hover:border-stone-300'
                }`}
              >
                <opt.icon className={`w-6 h-6 ${payment === opt.value ? 'text-amber-600' : 'text-stone-400'}`} />
                <div className="flex-1">
                  <div className="font-medium text-stone-800 text-sm">{opt.label}</div>
                  <div className="text-xs text-stone-500">{opt.desc}</div>
                </div>
                <div className={`w-5 h-5 rounded-full border-2 ${payment === opt.value ? 'border-amber-500 bg-amber-500' : 'border-stone-300'}`} />
              </button>
            ))}
          </div>
        </div>

        {/* Order summary */}
        <div className="bg-white rounded-xl border border-stone-200 p-4">
          <h2 className="font-semibold text-stone-800 mb-3">Chi tiết đơn hàng</h2>
          <div className="space-y-2 mb-4">
            {items.map((item) => (
              <div key={item.product.id} className="flex justify-between text-sm">
                <span className="text-stone-600">{item.product.name} × {item.quantity} {item.product.unit}</span>
                <span className="text-stone-800 font-medium">{formatPrice(item.product.price * item.quantity)}</span>
              </div>
            ))}
          </div>
          <div className="border-t border-stone-100 pt-3 space-y-2">
            <div className="flex justify-between text-sm">
              <span className="text-stone-600">Tạm tính</span>
              <span className="font-medium">{formatPrice(subtotal)}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-stone-600 flex items-center gap-1">
                <Truck className="w-4 h-4" /> Phí vận chuyển
                {distance > 0 && <span className="text-stone-400">({distance.toFixed(1)} km)</span>}
              </span>
              <span className="font-medium">
                {shippingFee === 0 ? <span className="text-emerald-600">Miễn phí</span> : formatPrice(shippingFee)}
              </span>
            </div>
            <div className="flex justify-between text-lg font-bold text-stone-800 border-t border-stone-100 pt-2">
              <span>Tổng cộng</span>
              <span className="text-amber-700">{formatPrice(total)}</span>
            </div>
          </div>
        </div>

        <button
          onClick={placeOrder}
          disabled={placing}
          className="w-full py-4 bg-amber-600 hover:bg-amber-500 text-white rounded-xl font-bold text-lg flex items-center justify-center gap-2 transition-colors disabled:opacity-50"
        >
          {placing ? <Loader2 className="w-5 h-5 animate-spin" /> : <CheckCircle2 className="w-5 h-5" />}
          {placing ? 'Đang đặt hàng...' : 'Xác nhận đặt hàng'}
        </button>
      </div>
    </div>
  );
}
