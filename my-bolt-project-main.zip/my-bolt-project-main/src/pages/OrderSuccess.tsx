import { useEffect, useState } from 'react';
import { CheckCircle2, Search, Home } from 'lucide-react';
import { useRouter } from '../lib/router';

export function OrderSuccess() {
  const { navigate } = useRouter();
  const [code, setCode] = useState('');

  useEffect(() => {
    const params = new URLSearchParams(window.location.hash.split('?')[1] || '');
    setCode(params.get('code') || '');
  }, []);

  return (
    <div className="max-w-2xl mx-auto px-4 py-12 text-center">
      <div className="w-20 h-20 rounded-full bg-emerald-100 flex items-center justify-center mx-auto mb-6">
        <CheckCircle2 className="w-12 h-12 text-emerald-600" />
      </div>
      <h1 className="text-2xl font-bold text-stone-800 mb-2">Đặt hàng thành công!</h1>
      <p className="text-stone-500 mb-2">Cửa hàng Song Thịnh đã nhận được đơn hàng của bạn.</p>
      {code && (
        <p className="text-stone-600 mb-6">
          Mã đơn hàng: <span className="font-bold text-amber-700 text-lg">{code}</span>
        </p>
      )}
      <div className="flex flex-wrap gap-3 justify-center">
        <button
          onClick={() => navigate('/track')}
          className="px-6 py-3 bg-amber-600 hover:bg-amber-500 text-white rounded-xl font-medium flex items-center gap-2 transition-colors"
        >
          <Search className="w-5 h-5" /> Theo dõi đơn hàng
        </button>
        <button
          onClick={() => navigate('/')}
          className="px-6 py-3 bg-white border border-stone-200 hover:bg-stone-50 text-stone-700 rounded-xl font-medium flex items-center gap-2 transition-colors"
        >
          <Home className="w-5 h-5" /> Về trang chủ
        </button>
      </div>
    </div>
  );
}
