import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export type Category = {
  id: string;
  name: string;
  slug: string;
  icon: string;
  sort_order: number;
};

export type Product = {
  id: string;
  category_id: string;
  name: string;
  description: string;
  price: number;
  unit: string;
  stock: number;
  image_url: string;
  is_active: boolean;
  created_at: string;
};

export type OrderStatus = 'pending' | 'confirmed' | 'delivering' | 'delivered' | 'cancelled';
export type PaymentMethod = 'cod' | 'deposit' | 'bank_transfer';

export type Order = {
  id: string;
  order_code: string;
  customer_name: string;
  customer_phone: string;
  address: string;
  lat: number | null;
  lng: number | null;
  notes: string;
  status: OrderStatus;
  payment_method: PaymentMethod;
  subtotal: number;
  shipping_fee: number;
  total: number;
  distance_km: number | null;
  created_at: string;
  updated_at: string;
};

export type OrderItem = {
  id: string;
  order_id: string;
  product_id: string | null;
  product_name: string;
  quantity: number;
  unit: string;
  price: number;
};

export type CartItem = {
  product: Product;
  quantity: number;
};

export const STATUS_LABELS: Record<OrderStatus, string> = {
  pending: 'Chờ xác nhận',
  confirmed: 'Đã xác nhận',
  delivering: 'Đang giao hàng',
  delivered: 'Đã giao thành công',
  cancelled: 'Đã hủy',
};

export const STATUS_COLORS: Record<OrderStatus, string> = {
  pending: 'bg-amber-100 text-amber-700 border-amber-300',
  confirmed: 'bg-blue-100 text-blue-700 border-blue-300',
  delivering: 'bg-indigo-100 text-indigo-700 border-indigo-300',
  delivered: 'bg-emerald-100 text-emerald-700 border-emerald-300',
  cancelled: 'bg-rose-100 text-rose-700 border-rose-300',
};

export const PAYMENT_LABELS: Record<PaymentMethod, string> = {
  cod: 'Thanh toán khi nhận hàng (COD)',
  deposit: 'Đặt cọc trước một phần',
  bank_transfer: 'Chuyển khoản ngân hàng',
};

export function formatPrice(n: number): string {
  return new Intl.NumberFormat('vi-VN').format(n) + ' ₫';
}

export function formatNumber(n: number): string {
  return new Intl.NumberFormat('vi-VN').format(n);
}
